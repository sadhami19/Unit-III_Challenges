def linear_search_product(product_list, target_product):
    # Initialize an empty list to store indices of the target product
    indices = []
    
    # Iterate through the product list using enumerate to track the index
    for i, product in enumerate(product_list):
        # Check if the current product matches the target product
        if product == target_product:
            # If there is a match, add the current index to the indices list
            indices.append(i)
    
    # Return the list of indices where the target product was found
    return indices

# Example usage:
products = ["apple", "banana", "apple", "orange", "apple"]
target = "apple"
result = linear_search_product(products, target)

# Check if the result is empty (product not found) or contains indices
if result:
    print("Indices of '{}' in the list: {}".format(target, result))
else:
    print("'{}' not found in the list.".format(target))
